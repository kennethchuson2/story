/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SuperRainbowReef.game;


import SuperRainbowReef.GameConstants;
import SuperRainbowReef.Launcher;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.util.Objects;
import java.util.ArrayList;


import static javax.imageio.ImageIO.read;

/**
 *
 * @author anthony-pc
 */
public class TRE extends JPanel implements Runnable {



    private BufferedImage world;

    private Launcher lf;
    private SeaShell player;
    private SeaStar weapon;
    private BigLeg enemy;

    private Map background;


    public int movex;
    public int movey;


    public TRE(Launcher lf){
        this.lf = lf;
    }

    @Override
    public void run(){
       try {

           while (true) {
                this.player.update();
                this.repaint();

               if (this.player.getHitBox().intersects(this.weapon.getHitBox())) {
                   weapon.setVy(-1);
               }
               if (this.weapon.getHitBox().intersects(this.enemy.getHitBox())) {
                   enemy.setAlive(false);
               }

                this.weapon.update();

                Thread.sleep(1000 / 144); //sleep for a few milliseconds


            }
       } catch (InterruptedException ignored) {
           System.out.println(ignored);
       }



    }


    public void gameInitialize() {
        this.world = new BufferedImage(GameConstants.GAME_SCREEN_WIDTH,
                                       GameConstants.GAME_SCREEN_HEIGHT,
                                       BufferedImage.TYPE_INT_RGB);

        BufferedImage t1img = null;
        BufferedImage t2img = null;
        BufferedImage t3img = null;


        try {

            t1img = read(Objects.requireNonNull(TRE.class.getClassLoader().getResource("Katch.gif")));
            t2img = read(Objects.requireNonNull(TRE.class.getClassLoader().getResource("Pop.png")));
            t3img = read(Objects.requireNonNull(TRE.class.getClassLoader().getResource("Bigleg.gif")));



        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }

        background= new Map();
        background.init();

        player = new SeaShell(200, 650, 5, t1img);
        weapon = new SeaStar(200, 400, 0, t2img);
        enemy = new BigLeg(200, 10, t3img);

        SeaShellControl tc1 = new SeaShellControl(player, KeyEvent.VK_RIGHT, KeyEvent.VK_LEFT);
        this.lf.getJf().addKeyListener(tc1);



    }




    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        Graphics2D buffer = world.createGraphics();
       // buffer.setColor(Color.BLACK);
        buffer.fillRect(0,0,GameConstants.GAME_SCREEN_WIDTH,GameConstants.GAME_SCREEN_HEIGHT);
        this.background.drawImage(buffer);
       // background.walls.forEach(wall -> wall.drawImage(buffer));
        //this.background.drawImage(buffer);
        this.player.drawImage(buffer);
       // this.t2.drawImage(buffer);
        this.weapon.drawImage(buffer);
        if (this.enemy.getAlive()) {
            this.enemy.drawImage(buffer);
        }
        g2.setFont(new Font("TimesRoman", Font.PLAIN, 25));
        g2.setColor(Color.BLACK);
        g2.drawString("Score : " + this.weapon.getScore(), GameConstants.GAME_SCREEN_WIDTH, GameConstants.GAME_SCREEN_HEIGHT);
        g2.drawImage(world,0,0,null);


    }

}
