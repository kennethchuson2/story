package SuperRainbowReef.game;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;

import static javax.imageio.ImageIO.read;

public class Map  {

    public static final int GAME_WIDTH = 1600;
    public static final int GAME_HEIGHT = 1000;
    public static ArrayList<GameObjects> objects = new ArrayList<>();
    private BufferedImage background, block1, block2, block3, block4;

    Map(){

    }

    public void init() {

        try {
            background = read(new File("resources/Background1.bmp"));
            block1 = read(new File("resources/Block1.gif"));
            block2 = read(new File("resources/Block_life.gif"));
            block3 = read(new File("resources/Block2.gif"));
            block4 = read(new File("resources/Block4.gif"));

            // increasedDamage = read(new File("resources/pickUp4.png"));
            //speedUp = read(new File("resources/pickUp1.png"));



        } catch (IOException e) {
        }


      InputStreamReader isr = new InputStreamReader(TRE.class.getClassLoader().getResourceAsStream("map1"));

        BufferedReader mapReader = new BufferedReader(isr);

        String row = null;
        try {
            row = mapReader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (row == null) {
            System.err.println("error");
        }
        String[] mapInfo = row.split("\t");
        int numCols = Integer.parseInt(mapInfo[0]);
        int numRows = Integer.parseInt(mapInfo[1]);


        for (int curRow = 0; curRow < numRows; curRow++) {
            try {
                row = mapReader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            mapInfo = row.split("\t");
            for (int curCol = 0; curCol < numCols; curCol++) {
                switch(mapInfo[curCol]) {
                    case "2":
                        Blocks br = new Blocks( curCol * 30, curRow * 30, block1);
                        objects.add(br);
                        break;
                    case "3":
                        Blocks_life br_life = new Blocks_life( curCol * 30, curRow * 30, block2);
                        objects.add(br_life);
                        break;
                    case "4":
                        Blocks br2 = new Blocks( curCol * 30, curRow * 30, block3);
                        objects.add(br2);
                        break;
                    case "5":
                        Blocks br3 = new Blocks( curCol * 30, curRow * 30, block4);
                        objects.add(br3);
                        break;

                }
            }
        }
    }

    void drawImage(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        for (int i = 0; i < GAME_WIDTH/background.getWidth()+1; i++){
            for (int j = 0; j <GAME_HEIGHT/background.getHeight()+1; j++){
                g2d.drawImage(background, background.getWidth() * i, background.getHeight() * j,null);
            }
        }
        for(int i = 0; i < objects.size(); i++){
            objects.get(i).drawImage(g2d);
        }
    }
}