package SuperRainbowReef.game;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Blocks extends GameObjects {

    private Rectangle bound;
    private int x, y;

    Blocks(int x, int y, BufferedImage img) {
        super(x, y, img);
        this.bound = new Rectangle(x,y,this.img.getWidth(), this.img.getHeight());
        gameObjects.add(this);
    }
}
