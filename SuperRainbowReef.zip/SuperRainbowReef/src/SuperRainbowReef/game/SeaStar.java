package SuperRainbowReef.game;

import SuperRainbowReef.GameConstants;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static javax.imageio.ImageIO.read;

public class SeaStar extends GameObjects {

    private final int R = 4;
    protected int x, y;
    protected int vx = 1;
    protected int vy = -1;
    protected int angle;
    boolean alive;
    private static BufferedImage seaStar;
    private Rectangle hitBox;
    private int score = 0;


    SeaShell player;
    BigLeg enemy;
    SeaStar ball;



    SeaStar(int x, int y, int angle, BufferedImage img) {
        super(x, y, img);
        this.x = x;
        this.y = y;
        this.angle = angle;
        alive = true;
        this.seaStar = img;
        this.hitBox = new Rectangle(x, y, this.seaStar.getWidth(), this.seaStar.getHeight());

    }





    public boolean isAlive() {
        return alive;
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public void setX(int x) {
        this.x = x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public void setY(int y) {
        this.y = y;
    }

    public int getVx() {
        return vx;
    }

    public void setVx(int vx) {
        this.vx = vx;
    }

    public void setVy(int vy) {
        this.vy = vy;
    }

    public int getVy() {
        return vy;
    }

    public void update() {

        x += vx;
        y += vy;

        if (x <= 0 || x + this.seaStar.getHeight() >= GameConstants.GAME_SCREEN_HEIGHT - 68) {
            vx = -vx;
        }
        if (y <= 0) {
            vy = -vy;
        }

        checkCollision(this);
        this.hitBox.setLocation(x, y);


    }

    public void checkCollision(SeaStar s){
        GameObjects obj;
        Rectangle tbound = s.getBounds();
        for (int i =0; i< Map.objects.size();i++){
            obj = Map.objects.get(i);
            if (tbound.intersects(obj.getBounds())){
                if(obj instanceof Blocks || obj instanceof Blocks_life) {
                    Map.objects.remove(obj);
                    vy = -vy;
                    score++;
                }
            }
        }
    }

    public Rectangle getHitBox() {
        return hitBox.getBounds();
    }


    public int getScore() {
        return score;
    }





    public Rectangle getBounds(){
        return this.hitBox;
    }




    public void drawImage(Graphics g) {
        AffineTransform rotation = AffineTransform.getTranslateInstance(x, y);
      //  rotation.rotate(Math.toRadians(angle), this.seaStar.getWidth(), this.seaStar.getHeight());
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawImage(this.seaStar, rotation, null);


    }
}
