package SuperRainbowReef.game;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

public class BigLeg extends GameObjects {

    private final int R = 4;
    protected int x, y;
    protected int vx = 1;
    protected int vy = -1;
    private boolean alive;
    private static BufferedImage bigLeg;
    private Rectangle hitBox;



    BigLeg(int x, int y, BufferedImage img) {
        super(x, y, img);
        this.x = x;
        this.y = y;
        alive = true;
        this.bigLeg = img;
        this.hitBox = new Rectangle(x, y, this.bigLeg.getWidth(), this.bigLeg.getHeight());
        gameObjects.add(this);
    }

    public void setAlive(boolean check) {
        alive = check;
    }

    public boolean getAlive() {
        return alive;
    }

    public Rectangle getBounds(){
        return this.hitBox;
    }

    public Rectangle getHitBox() {
        return hitBox.getBounds();
    }



    public void drawImage(Graphics g) {
        AffineTransform rotation = AffineTransform.getTranslateInstance(x, y);
        Graphics2D g2d = (Graphics2D) g;
        if (getAlive()) {
            g2d.drawImage(this.bigLeg, rotation, null);
        }

    }
}
