package SuperRainbowReef.game;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import SuperRainbowReef.GameConstants;

public class SeaShell extends GameObjects {


    private int x;
    private int y;
    private int vx;


    private final int R = 2;
    private Rectangle hitBox;



    private BufferedImage img;
    private boolean RightPressed;
    private boolean LeftPressed;
    private Rectangle tbound;
    private GameObjects obj;


    SeaShell(int x, int y, int vx, BufferedImage img) {
        super(x, y, img);
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.img = img;
        this.hitBox = new Rectangle(x, y, this.img.getWidth(), this.img.getHeight());
        Map.objects.add(this);


    }




    void toggleRightPressed() {
        this.RightPressed = true;
    }

    void toggleLeftPressed() {
        this.LeftPressed = true;
    }

    void unToggleRightPressed() {
        this.RightPressed = false;
    }

    void unToggleLeftPressed() {
        this.LeftPressed = false;
    }

    public void setX(int x){ this.x = x; }

    public void setY(int y) { this.y = y; }

    public int getX() {
        return x;
    }

    public int getY() { return y; }

    public int getVx() {
        return vx;
    }

    public void setVx(int vx) {
        this.vx = vx;
    }


    public boolean isRightPressed() {
        return RightPressed;
    }

    public boolean isLeftPressed() {
        return LeftPressed;
    }

    void update() {

        if (this.LeftPressed) {
           this.moveForwards();
        }
        if (this.RightPressed) {
            this.moveBackwards();
        }
    }


    private void moveBackwards() {
        x -= vx;
        checkBorder();
        this.hitBox.setLocation(x, y);
    }

    private void moveForwards() {
        x += vx;
        checkBorder();
        this.hitBox.setLocation(x, y);

    }

    public void checkCollision(SeaShell s){
        tbound = s.getBounds();
        for (int i =0; i< Map.objects.size();i++){
            obj = Map.objects.get(i);
            if (tbound.intersects(obj.getBounds())){
                handle(obj);
            }
        }
    }

    public Rectangle getHitBox() {
        return hitBox.getBounds();
    }





    public Rectangle getBounds(){
        return this.hitBox;
    }



    public void handle(GameObjects obj) {
        if (obj instanceof SeaStar) {

        }
    }







    private void checkBorder() {
        if (x < 30) {
            x = 30;
        }
        if (x >= GameConstants.GAME_SCREEN_WIDTH - 88) {
            x = GameConstants.GAME_SCREEN_WIDTH - 88;
        }
        if (y < 40) {
            y = 40;
        }
        if (y >= GameConstants.GAME_SCREEN_HEIGHT - 80) {
            y = GameConstants.GAME_SCREEN_HEIGHT - 80;
        }
    }

    @Override
    public String toString() {
        return "x = " + x;
    }


    public void drawImage(Graphics g) {
        AffineTransform rotation = AffineTransform.getTranslateInstance(x, y);
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawImage(this.img, rotation, null);
        g2d.drawRect(x, y, this.img.getWidth(), this.img.getHeight());
    }



}
